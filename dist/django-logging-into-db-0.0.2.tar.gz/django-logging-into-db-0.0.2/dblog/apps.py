from django.apps import AppConfig


class DblogConfig(AppConfig):
    name = 'dblog'
    verbose_name = 'Error Logs'
